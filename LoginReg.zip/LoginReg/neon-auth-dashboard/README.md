# Neon Authentication Dashboard

This project is a simple login and registration dashboard built using Node.js, Express, and the Neon database. It provides user authentication features, including registration, login, and user profile management.

## Features

- User registration
- User login
- Password hashing and validation
- Middleware for authentication
- User profile management

## Technologies Used

- Node.js
- Express
- TypeScript
- Neon Database
- dotenv for environment variable management

## Getting Started

### Prerequisites

- Node.js installed on your machine
- A Neon database account

### Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd neon-auth-dashboard
   ```

3. Install the dependencies:
   ```
   npm install
   ```

4. Create a `.env` file in the root directory and add your database connection string and any other necessary environment variables.

### Running the Application

To start the application, run:
```
npm start
```

The server will start on the specified port, and you can access the API endpoints for authentication and user management.

## API Endpoints

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Log in an existing user
- `GET /api/user/profile` - Get user profile information (requires authentication)

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License.