class AuthController {
    async register(req, res) {
        // Logic for user registration
    }

    async login(req, res) {
        // Logic for user login
    }

    async logout(req, res) {
        // Logic for user logout
    }
}

export default new AuthController();