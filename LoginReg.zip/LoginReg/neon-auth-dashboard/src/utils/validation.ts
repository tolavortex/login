export function validateRegistration(data: any) {
    const errors: string[] = [];
    
    if (!data.username || data.username.trim() === '') {
        errors.push('Username is required.');
    }
    
    if (!data.password || data.password.length < 6) {
        errors.push('Password must be at least 6 characters long.');
    }
    
    if (!data.email || !/\S+@\S+\.\S+/.test(data.email)) {
        errors.push('A valid email is required.');
    }
    
    return {
        isValid: errors.length === 0,
        errors
    };
}

export function validateLogin(data: any) {
    const errors: string[] = [];
    
    if (!data.username || data.username.trim() === '') {
        errors.push('Username is required.');
    }
    
    if (!data.password) {
        errors.push('Password is required.');
    }
    
    return {
        isValid: errors.length === 0,
        errors
    };
}